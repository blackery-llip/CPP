+ 视频直达：[C++标准库(STL)与泛型编程](https://www.bilibili.com/video/BV1BX4y1G7bX)
+ 课程讲义下载直达：[slide](slide/)
+ 源代码直达：[code](code/)

----

候捷老师 C++ 系列课程导航：（编号顺序可作为学习顺序参考） 

1. [C++面向对象高级编程（上）-基于对象和面向对象](../C++-OOPBase1-HouJie/)
2. [C++面向对象高级编程（下）-兼谈对象模型](../C++-OOPBase2-HouJie/)
3. C++标准库(STL)与泛型编程
4. [C++新标准-C++11/14](../C++-newC++11&14-HouJie/)
5. [C++内存管理](../C++-MemoryManagement-HouJie/)
6. [C++Startup揭秘](https://github.com/19PDP/Bilibili-plus)